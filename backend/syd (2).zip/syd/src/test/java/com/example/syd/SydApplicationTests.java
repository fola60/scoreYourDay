package com.example.syd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SydApplicationTests {

	@Test
	void contextLoads() {
	}

}
